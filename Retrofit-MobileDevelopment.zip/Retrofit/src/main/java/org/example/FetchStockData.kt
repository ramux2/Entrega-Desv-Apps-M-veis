package org.example

import org.jsoup.Jsoup
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

fun fetchStockDataWithJsoup(code: String) {
    val call = RetrofitClient.instance.getStockPage(code)

    call.enqueue(object : Callback<ResponseBody> {
        override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
            if (response.isSuccessful) {
                val html = response.body()?.string()
                if (html != null) {
                    val doc = Jsoup.parse(html)
                    val quoteElement = doc.select("span.value").first()?.text()
                    println("Current Quote: $quoteElement")
                    fetchDividends(doc)
                }
            } else {
                println("Error retrieving page data. Status code: ${response.code()}")
            }
        }

        override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
            println("Error: ${t.message}")
        }
    })
}

fun fetchDividends(doc: org.jsoup.nodes.Document) {
    try {
        val dividendsTable = doc.select("table.table-dividends-history tbody tr")

        for (row in dividendsTable) {
            val type = row.select("td").get(0).text()
            val dateCom = row.select("td").get(1).text()
            val paymentDate = row.select("td").get(2).text()
            val value = row.select("td").get(3).text()

            println("Type: $type, Ex-dividend date: $dateCom, Payment date: $paymentDate, Value: $value")
        }
    } catch (e: Exception) {
        println("Error fetching dividends: ${e.message}")
    }
}
