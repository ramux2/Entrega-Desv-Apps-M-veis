package org.example

fun main() {
    // Testing the function with the stock code "vale3"
    fetchStockDataWithJsoup("vale3")
}
