package org.example

data class Quote(
    val currentValue: Double
)

data class Dividend(
    val paymentDate: String,
    val value: Double
)

data class StockInfo(
    val quote: Quote,
    val dividends: List<Dividend>
)
