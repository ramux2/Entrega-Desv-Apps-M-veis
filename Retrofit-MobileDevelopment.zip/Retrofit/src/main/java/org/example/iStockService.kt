package org.example

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface StockService {

    @GET("https://investidor10.com.br/acoes/{code}/")
    fun getStockPage(@Path("code") code: String): Call<ResponseBody>
}
